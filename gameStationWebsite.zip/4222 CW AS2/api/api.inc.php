<?php 
    //Include our Internal Framework API Scripts
    require_once("funcLogicLayer.php");     //Functions - Business Logic Layer
	require_once("funcPresLayer.php");      //Functions - Presentation Layer
	require_once("htmlPageSys.php");    //Objects - Page System - HTML Base
	require_once("masterPageSys.php");  //Objects - Page System - Master Page
	require_once("objLogicLayer.php");     //Objects - Business Logic Layer
	require_once("dataAccessLayer.php");     //Functions - Data Access Layer
	require_once("objOrientatedPresLayer.php");	    //Functions - Presentation Layer
?>